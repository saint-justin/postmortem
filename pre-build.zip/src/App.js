import React from "react";
import TestForm from './components/test-form/test-form.js'

import logo from "./logo.svg";
import "./App.scss";

function App() {
  return (
    <div className="App">
      <TestForm />
    </div>
  );
}

export default App;
